var searchData=
[
  ['exec',['Exec',['../group__syscalls.html#ga737ad30d8105b4b76e3eb102dd016404',1,'tinyos.h']]],
  ['execute',['Execute',['../tinyoslib_8h.html#a0e11b5da87f467679adbb23883328c2d',1,'tinyoslib.c']]],
  ['exit',['Exit',['../group__syscalls.html#gabed0249344c12ecd4f8d440fc05a360a',1,'tinyos.h']]],
  ['expect',['expect',['../group__Testing.html#ga0c4e801b8c3317b802fa4e80e1e26de2',1,'unit_testing.h']]]
];
