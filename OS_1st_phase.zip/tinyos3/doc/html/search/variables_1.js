var searchData=
[
  ['bites',['bites',['../structsymposium__t.html#a9ee1b978200b8a4b7c30b170c1f20643',1,'symposium_t']]]
];
