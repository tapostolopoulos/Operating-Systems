var searchData=
[
  ['logrec',['logrec',['../structlogrec.html',1,'']]]
];
