var searchData=
[
  ['symposium_2eh',['symposium.h',['../symposium_8h.html',1,'']]]
];
