var searchData=
[
  ['xmalloc',['xmalloc',['../group__check__macros.html#ga1d16f442903359e8146370c52297334c',1,'util.h']]]
];
