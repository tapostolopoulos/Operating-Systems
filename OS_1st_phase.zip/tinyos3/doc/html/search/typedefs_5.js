var searchData=
[
  ['pcb',['PCB',['../group__proc.html#gadf327f09ee935cf1734c14e8849f0421',1,'PCB():&#160;kernel_proc.h'],['../group__rlists.html#ga91aaadf0c3f9cef2293a99c69795323f',1,'PCB():&#160;util.h']]],
  ['pid_5fstate',['pid_state',['../group__proc.html#gade1eea4d20492c4c97263201145e5097',1,'kernel_proc.h']]],
  ['pid_5ft',['Pid_t',['../group__syscalls.html#gafac07f3170763932fac97b6eab2c3984',1,'tinyos.h']]],
  ['pipe_5ft',['pipe_t',['../group__syscalls.html#gad56b5ceaaf7d3ab88b4be7f622314dfb',1,'tinyos.h']]],
  ['port_5ft',['port_t',['../group__syscalls.html#ga13894e5a2ffd5febb7aeb90e87239d61',1,'tinyos.h']]],
  ['procinfo',['procinfo',['../group__syscalls.html#ga9682d9066f643f8d18cff58fd3fb09b9',1,'tinyos.h']]],
  ['program',['Program',['../tinyoslib_8h.html#ab518accf2c30e915a8250c0ae308aefd',1,'tinyoslib.h']]]
];
