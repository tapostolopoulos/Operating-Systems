var searchData=
[
  ['parseprocinfo',['ParseProcInfo',['../tinyoslib_8h.html#ab98738d69f4b198fbcad1a6f2e20a44d',1,'tinyoslib.c']]],
  ['pipe',['Pipe',['../group__syscalls.html#gab6355ce54e047c31538ed5ed9108b5b3',1,'tinyos.h']]]
];
