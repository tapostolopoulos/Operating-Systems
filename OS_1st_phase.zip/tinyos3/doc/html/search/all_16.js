var searchData=
[
  ['waitchild',['WaitChild',['../group__syscalls.html#ga37017afba05480740d26b033975fef03',1,'tinyos.h']]],
  ['waitset',['waitset',['../structCondVar.html#a7da9e0169713c3b3ae386a8ab49f7e34',1,'CondVar']]],
  ['waitset_5flock',['waitset_lock',['../structCondVar.html#a477b855f4d3880d231206ae79bd5b6cf',1,'CondVar']]],
  ['wakeup',['wakeup',['../group__scheduler.html#gae8301452fd9ae5bf7cd7f2676650ff06',1,'wakeup(TCB *tcb):&#160;kernel_sched.c'],['../group__scheduler.html#gae8301452fd9ae5bf7cd7f2676650ff06',1,'wakeup(TCB *tcb):&#160;kernel_sched.c']]],
  ['wakeup_5ftime',['wakeup_time',['../structthread__control__block.html#a7dbf9ba7df67911abb7951e249f587b6',1,'thread_control_block']]],
  ['write',['Write',['../structfile__operations.html#a75d4020e8a146c1611dc40184d211ec6',1,'file_operations::Write()'],['../structpipe__s.html#a69acc9cdf5f10195c43491e3ffa98cb1',1,'pipe_s::write()'],['../group__syscalls.html#gaf046f003fde24f79fb395c250137856c',1,'Write():&#160;tinyos.h']]]
];
