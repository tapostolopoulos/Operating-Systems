var searchData=
[
  ['quantum',['QUANTUM',['../group__scheduler.html#gabc4f0f9abea1b5443308e4ea84b52b21',1,'kernel_sched.h']]]
];
