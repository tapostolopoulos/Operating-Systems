var searchData=
[
  ['device_5fno',['device_no',['../group__dev.html#ga0808cf584a510e0eff6908a5313ce296',1,'device_no(Device_type major):&#160;kernel_dev.c'],['../group__dev.html#ga0808cf584a510e0eff6908a5313ce296',1,'device_no(Device_type major):&#160;kernel_dev.c']]],
  ['device_5fopen',['device_open',['../group__dev.html#ga6d8e08550640c9819aa07b6bba9fa6ed',1,'device_open(Device_type major, uint minor, void **obj, file_ops **ops):&#160;kernel_dev.c'],['../group__dev.html#ga6d8e08550640c9819aa07b6bba9fa6ed',1,'device_open(Device_type major, uint minor, void **obj, file_ops **ops):&#160;kernel_dev.c']]],
  ['dup2',['Dup2',['../group__syscalls.html#gacc048c60209e2dfb4b5cfc1c3f21aa88',1,'tinyos.h']]]
];
