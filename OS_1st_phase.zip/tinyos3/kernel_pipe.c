
#include "tinyos.h"


int sys_Pipe(pipe_t* pipe)
{
	return -1;
}

